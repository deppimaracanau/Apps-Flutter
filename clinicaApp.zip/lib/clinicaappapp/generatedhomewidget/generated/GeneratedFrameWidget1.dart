import 'package:flutter/material.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget272.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget217.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget264.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget285.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget237.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget200.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget214.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget278.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget276.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget270.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget204.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget286.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget258.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget292.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget236.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget241.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget198.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget206.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget296.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget187.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget213.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget247.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget250.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget226.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget246.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget289.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget216.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget281.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget257.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget298.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget248.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedGroupWidget14.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget279.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget282.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget294.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget233.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget297.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget201.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget283.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget277.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget253.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget251.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget218.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget188.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget293.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget242.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget215.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget268.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget274.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget205.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget221.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget235.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget288.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget223.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget185.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget219.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget290.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget227.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget291.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget225.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget224.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget243.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget230.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget260.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget211.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget186.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget252.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget203.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget261.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget295.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedGroupWidget16.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget202.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget259.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget212.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget269.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget222.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget234.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget266.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget238.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget220.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget254.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget210.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedGroupWidget15.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget228.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget267.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget256.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget245.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget255.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget249.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget284.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget231.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget271.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedGroupWidget18.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget229.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget239.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget209.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget275.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget265.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget199.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget240.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedGroupWidget17.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget273.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget280.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget208.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget207.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget232.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget262.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget263.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget244.dart';
import 'package:flutterapp/clinicaappapp/generatedhomewidget/generated/GeneratedVectorWidget287.dart';

/* Frame Frame
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedFrameWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.zero,
      child: Container(
        width: 175.0,
        height: 130.28846740722656,
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              Positioned(
                left: 71.97840118408203,
                top: 38.97038650512695,
                right: null,
                bottom: null,
                width: 18.65808868408203,
                height: 29.117656707763672,
                child: GeneratedGroupWidget14(),
              ),
              Positioned(
                left: 65.06201171875,
                top: 38.97038650512695,
                right: null,
                bottom: null,
                width: 18.65808868408203,
                height: 29.157711029052734,
                child: GeneratedGroupWidget15(),
              ),
              Positioned(
                left: 58.34674835205078,
                top: 0.20026011765003204,
                right: null,
                bottom: null,
                width: 22.196701049804688,
                height: 31.480712890625,
                child: GeneratedGroupWidget16(),
              ),
              Positioned(
                left: 132.33563232421875,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.0317840576171875,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget185(),
              ),
              Positioned(
                left: 131.25006103515625,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.0317230224609375,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget186(),
              ),
              Positioned(
                left: 135.2711944580078,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.3026123046875,
                height: 54.99110412597656,
                child: GeneratedVectorWidget187(),
              ),
              Positioned(
                left: 37.71826171875,
                top: 32.84246826171875,
                right: null,
                bottom: null,
                width: 11.741722106933594,
                height: 6.0951385498046875,
                child: GeneratedVectorWidget188(),
              ),
              Positioned(
                left: 33.80284118652344,
                top: 13.718849182128906,
                right: null,
                bottom: null,
                width: 18.528629302978516,
                height: 26.773513793945312,
                child: GeneratedGroupWidget17(),
              ),
              Positioned(
                left: 33.214630126953125,
                top: 93.24056243896484,
                right: null,
                bottom: null,
                width: 6.9163665771484375,
                height: 30.799827575683594,
                child: GeneratedVectorWidget198(),
              ),
              Positioned(
                left: 22.598833084106445,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031703948974609,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget199(),
              ),
              Positioned(
                left: 21.51308822631836,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031709671020508,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget200(),
              ),
              Positioned(
                left: 18.416790008544922,
                top: 120.99645233154297,
                right: null,
                bottom: null,
                width: 36.51194763183594,
                height: 4.40570068359375,
                child: GeneratedVectorWidget201(),
              ),
              Positioned(
                left: 17.652799606323242,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031709671020508,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget202(),
              ),
              Positioned(
                left: 16.567115783691406,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031703948974609,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget203(),
              ),
              Positioned(
                left: 49.70128631591797,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031715393066406,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget204(),
              ),
              Positioned(
                left: 48.61555099487305,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031711578369141,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget205(),
              ),
              Positioned(
                left: 11.592177391052246,
                top: 45.13837432861328,
                right: null,
                bottom: null,
                width: 36.90276336669922,
                height: 46.179710388183594,
                child: GeneratedVectorWidget206(),
              ),
              Positioned(
                left: 23.234018325805664,
                top: 38.16935729980469,
                right: null,
                bottom: null,
                width: 4.278797149658203,
                height: 9.772636413574219,
                child: GeneratedVectorWidget207(),
              ),
              Positioned(
                left: 8.66547966003418,
                top: 23.430294036865234,
                right: null,
                bottom: null,
                width: 26.941801071166992,
                height: 18.383773803710938,
                child: GeneratedVectorWidget208(),
              ),
              Positioned(
                left: 64.74034881591797,
                top: 116.3905029296875,
                right: null,
                bottom: null,
                width: 6.87615966796875,
                height: 7.6498870849609375,
                child: GeneratedVectorWidget209(),
              ),
              Positioned(
                left: 62.95454406738281,
                top: 120.11530303955078,
                right: null,
                bottom: null,
                width: 20.926467895507812,
                height: 9.972908020019531,
                child: GeneratedVectorWidget210(),
              ),
              Positioned(
                left: 32.93311309814453,
                top: 77.6604232788086,
                right: null,
                bottom: null,
                width: 40.492881774902344,
                height: 39.57115173339844,
                child: GeneratedVectorWidget211(),
              ),
              Positioned(
                left: 54.12455368041992,
                top: 116.3905029296875,
                right: null,
                bottom: null,
                width: 6.8761444091796875,
                height: 7.6498870849609375,
                child: GeneratedVectorWidget212(),
              ),
              Positioned(
                left: 22.79989242553711,
                top: 77.6604232788086,
                right: null,
                bottom: null,
                width: 40.49288558959961,
                height: 39.57115173339844,
                child: GeneratedVectorWidget213(),
              ),
              Positioned(
                left: 32.77228546142578,
                top: 85.23021697998047,
                right: null,
                bottom: null,
                width: 3.498394012451172,
                height: 6.087867736816406,
                child: GeneratedVectorWidget214(),
              ),
              Positioned(
                left: 22.79989242553711,
                top: 37.52853012084961,
                right: null,
                bottom: null,
                width: 34.09926223754883,
                height: 44.217159271240234,
                child: GeneratedVectorWidget215(),
              ),
              Positioned(
                left: 41.73941421508789,
                top: 43.61639404296875,
                right: null,
                bottom: null,
                width: 1.889923095703125,
                height: 34.52465057373047,
                child: GeneratedVectorWidget216(),
              ),
              Positioned(
                left: 46.68545150756836,
                top: 37.52853012084961,
                right: null,
                bottom: null,
                width: 15.419925689697266,
                height: 40.131893157958984,
                child: GeneratedVectorWidget217(),
              ),
              Positioned(
                left: 49.460018157958984,
                top: 35.125423431396484,
                right: null,
                bottom: null,
                width: 16.34970474243164,
                height: 32.96261978149414,
                child: GeneratedVectorWidget218(),
              ),
              Positioned(
                left: 20.548036575317383,
                top: 35.6861457824707,
                right: null,
                bottom: null,
                width: 15.722658157348633,
                height: 55.63193893432617,
                child: GeneratedVectorWidget219(),
              ),
              Positioned(
                left: 97.6332015991211,
                top: 30.55951499938965,
                right: null,
                bottom: null,
                width: 8.364044189453125,
                height: 7.850149154663086,
                child: GeneratedVectorWidget220(),
              ),
              Positioned(
                left: 0.2010640799999237,
                top: 68.08804321289062,
                right: null,
                bottom: null,
                width: 174.63812255859375,
                height: 7.0491180419921875,
                child: GeneratedVectorWidget221(),
              ),
              Positioned(
                left: 63.29273986816406,
                top: 50.58540725708008,
                right: null,
                bottom: null,
                width: 1.7290878295898438,
                height: 5.366947174072266,
                child: GeneratedVectorWidget222(),
              ),
              Positioned(
                left: 64.86094665527344,
                top: 51.22624206542969,
                right: null,
                bottom: null,
                width: 1.7290878295898438,
                height: 5.366943359375,
                child: GeneratedVectorWidget223(),
              ),
              Positioned(
                left: 60.97972106933594,
                top: 50.197410583496094,
                right: null,
                bottom: null,
                width: 14.376426696777344,
                height: 12.203277587890625,
                child: GeneratedVectorWidget224(),
              ),
              Positioned(
                left: 100.66962432861328,
                top: 17.222272872924805,
                right: null,
                bottom: null,
                width: 13.228805541992188,
                height: 18.664133071899414,
                child: GeneratedVectorWidget225(),
              ),
              Positioned(
                left: 97.7539291381836,
                top: 14.43774700164795,
                right: null,
                bottom: null,
                width: 17.00940704345703,
                height: 15.48094654083252,
                child: GeneratedVectorWidget226(),
              ),
              Positioned(
                left: 113.91886138916016,
                top: 23.864919662475586,
                right: null,
                bottom: null,
                width: 1.77923583984375,
                height: 4.171333312988281,
                child: GeneratedVectorWidget227(),
              ),
              Positioned(
                left: 98.86991882324219,
                top: 23.864919662475586,
                right: null,
                bottom: null,
                width: 1.77923583984375,
                height: 4.171333312988281,
                child: GeneratedVectorWidget228(),
              ),
              Positioned(
                left: 105.98268127441406,
                top: 30.55951499938965,
                right: null,
                bottom: null,
                width: 9.343559265136719,
                height: 4.125333786010742,
                child: GeneratedVectorWidget229(),
              ),
              Positioned(
                left: 99.72425842285156,
                top: 31.921281814575195,
                right: null,
                bottom: null,
                width: 18.17554473876953,
                height: 4.445749282836914,
                child: GeneratedVectorWidget230(),
              ),
              Positioned(
                left: 102.69996643066406,
                top: 33.643497467041016,
                right: null,
                bottom: null,
                width: 19.54277801513672,
                height: 2.763580322265625,
                child: GeneratedVectorWidget231(),
              ),
              Positioned(
                left: 72.60869598388672,
                top: 36.420074462890625,
                right: null,
                bottom: null,
                width: 60.12224578857422,
                height: 52.22752380371094,
                child: GeneratedVectorWidget232(),
              ),
              Positioned(
                left: 122.92623138427734,
                top: 40.97298049926758,
                right: null,
                bottom: null,
                width: 2.9354476928710938,
                height: 27.15511703491211,
                child: GeneratedVectorWidget233(),
              ),
              Positioned(
                left: 125.01726531982422,
                top: 49.22364807128906,
                right: null,
                bottom: null,
                width: 2.493133544921875,
                height: 8.611125946044922,
                child: GeneratedVectorWidget234(),
              ),
              Positioned(
                left: 90.84944915771484,
                top: 80.98471069335938,
                right: null,
                bottom: null,
                width: 20.550567626953125,
                height: 38.289520263671875,
                child: GeneratedVectorWidget235(),
              ),
              Positioned(
                left: 103.98664855957031,
                top: 116.15018463134766,
                right: null,
                bottom: null,
                width: 8.122634887695312,
                height: 8.130516052246094,
                child: GeneratedVectorWidget236(),
              ),
              Positioned(
                left: 91.27670288085938,
                top: 120.6673355102539,
                right: null,
                bottom: null,
                width: 22.740478515625,
                height: 9.380821228027344,
                child: GeneratedVectorWidget237(),
              ),
              Positioned(
                left: 91.67374420166016,
                top: 88.46882629394531,
                right: null,
                bottom: null,
                width: 16.41448211669922,
                height: 9.658058166503906,
                child: GeneratedVectorWidget238(),
              ),
              Positioned(
                left: 77.30558776855469,
                top: 77.6604232788086,
                right: null,
                bottom: null,
                width: 49.758872985839844,
                height: 41.573768615722656,
                child: GeneratedVectorWidget239(),
              ),
              Positioned(
                left: 91.15925598144531,
                top: 116.3504638671875,
                right: null,
                bottom: null,
                width: 8.565040588378906,
                height: 8.571067810058594,
                child: GeneratedVectorWidget240(),
              ),
              Positioned(
                left: 92.28515625,
                top: 77.82062530517578,
                right: null,
                bottom: null,
                width: 9.530097961425781,
                height: 3.1640853881835938,
                child: GeneratedVectorWidget241(),
              ),
              Positioned(
                left: 107.28397369384766,
                top: 46.13966369628906,
                right: null,
                bottom: null,
                width: 37.94507598876953,
                height: 51.987220764160156,
                child: GeneratedVectorWidget242(),
              ),
              Positioned(
                left: 97.03008270263672,
                top: 93.24056243896484,
                right: null,
                bottom: null,
                width: 10.776641845703125,
                height: 0.0,
                child: GeneratedVectorWidget243(),
              ),
              Positioned(
                left: 111.42572021484375,
                top: 98.12688446044922,
                right: null,
                bottom: null,
                width: 24.327926635742188,
                height: 5.607246398925781,
                child: GeneratedVectorWidget244(),
              ),
              Positioned(
                left: 24.00623893737793,
                top: 98.12688446044922,
                right: null,
                bottom: null,
                width: 25.695070266723633,
                height: 5.607246398925781,
                child: GeneratedVectorWidget245(),
              ),
              Positioned(
                left: 120.91567993164062,
                top: 93.24056243896484,
                right: null,
                bottom: null,
                width: 6.916351318359375,
                height: 30.799827575683594,
                child: GeneratedVectorWidget246(),
              ),
              Positioned(
                left: 110.46074676513672,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031707763671875,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget247(),
              ),
              Positioned(
                left: 109.375,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031707763671875,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget248(),
              ),
              Positioned(
                left: 106.11793518066406,
                top: 120.99645233154297,
                right: null,
                bottom: null,
                width: 36.511932373046875,
                height: 4.40570068359375,
                child: GeneratedVectorWidget249(),
              ),
              Positioned(
                left: 105.39399719238281,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031707763671875,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget250(),
              ),
              Positioned(
                left: 104.26811218261719,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.031715393066406,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget251(),
              ),
              Positioned(
                left: 137.4425506591797,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.0316925048828125,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget252(),
              ),
              Positioned(
                left: 136.31663513183594,
                top: 124.04039001464844,
                right: null,
                bottom: null,
                width: 6.0316925048828125,
                height: 6.0077667236328125,
                child: GeneratedVectorWidget253(),
              ),
              Positioned(
                left: 77.88636016845703,
                top: 120.6673355102539,
                right: null,
                bottom: null,
                width: 22.740463256835938,
                height: 9.380821228027344,
                child: GeneratedVectorWidget254(),
              ),
              Positioned(
                left: 98.71895599365234,
                top: 44.05696487426758,
                right: null,
                bottom: null,
                width: 0.68359375,
                height: 9.09176254272461,
                child: GeneratedVectorWidget255(),
              ),
              Positioned(
                left: 85.7306900024414,
                top: 58.355445861816406,
                right: null,
                bottom: null,
                width: 1.0052871704101562,
                height: 3.0439529418945312,
                child: GeneratedVectorWidget256(),
              ),
              Positioned(
                left: 84.28308868408203,
                top: 84.90979766845703,
                right: null,
                bottom: null,
                width: 4.7449493408203125,
                height: 2.2028350830078125,
                child: GeneratedVectorWidget257(),
              ),
              Positioned(
                left: 16.969234466552734,
                top: 91.31808471679688,
                right: null,
                bottom: null,
                width: 34.622013092041016,
                height: 6.808799743652344,
                child: GeneratedVectorWidget258(),
              ),
              Positioned(
                left: 52.057247161865234,
                top: 120.11530303955078,
                right: null,
                bottom: null,
                width: 20.926448822021484,
                height: 9.972908020019531,
                child: GeneratedVectorWidget259(),
              ),
              Positioned(
                left: 11.01924991607666,
                top: 37.52853012084961,
                right: null,
                bottom: null,
                width: 23.482135772705078,
                height: 30.519466400146484,
                child: GeneratedVectorWidget260(),
              ),
              Positioned(
                left: 30.399818420410156,
                top: 60.83866882324219,
                right: null,
                bottom: null,
                width: 1.60845947265625,
                height: 1.6020584106445312,
                child: GeneratedVectorWidget261(),
              ),
              Positioned(
                left: 48.09284210205078,
                top: 35.125423431396484,
                right: null,
                bottom: null,
                width: 8.88003158569336,
                height: 26.514270782470703,
                child: GeneratedVectorWidget262(),
              ),
              Positioned(
                left: 29.153989791870117,
                top: 35.125423431396484,
                right: null,
                bottom: null,
                width: 8.564321517944336,
                height: 25.112457275390625,
                child: GeneratedVectorWidget263(),
              ),
              Positioned(
                left: 33.89817428588867,
                top: 35.125423431396484,
                right: null,
                bottom: null,
                width: 9.771358489990234,
                height: 6.363773345947266,
                child: GeneratedVectorWidget264(),
              ),
              Positioned(
                left: 43.54890441894531,
                top: 35.165470123291016,
                right: null,
                bottom: null,
                width: 9.570316314697266,
                height: 6.4935302734375,
                child: GeneratedVectorWidget265(),
              ),
              Positioned(
                left: 38.643165588378906,
                top: 42.895469665527344,
                right: null,
                bottom: null,
                width: 6.996784210205078,
                height: 22.989730834960938,
                child: GeneratedVectorWidget266(),
              ),
              Positioned(
                left: 42.342567443847656,
                top: 40.93292999267578,
                right: null,
                bottom: null,
                width: 2.4126853942871094,
                height: 2.6849937438964844,
                child: GeneratedVectorWidget267(),
              ),
              Positioned(
                left: 41.940452575683594,
                top: 37.56857681274414,
                right: null,
                bottom: null,
                width: 3.4983901977539062,
                height: 4.285545349121094,
                child: GeneratedVectorWidget268(),
              ),
              Positioned(
                left: 39.6484489440918,
                top: 61.03892135620117,
                right: null,
                bottom: null,
                width: 5.026424407958984,
                height: 1.6821861267089844,
                child: GeneratedVectorWidget269(),
              ),
              Positioned(
                left: 37.308067321777344,
                top: 55.604671478271484,
                right: null,
                bottom: null,
                width: 8.854595184326172,
                height: 11.962703704833984,
                child: GeneratedVectorWidget270(),
              ),
              Positioned(
                left: 35.627315521240234,
                top: 67.08674621582031,
                right: null,
                bottom: null,
                width: 25.051700592041016,
                height: 1.041351318359375,
                child: GeneratedVectorWidget271(),
              ),
              Positioned(
                left: 33.33523941040039,
                top: 60.63457489013672,
                right: null,
                bottom: null,
                width: 12.063419342041016,
                height: 7.493522644042969,
                child: GeneratedVectorWidget272(),
              ),
              Positioned(
                left: 40.37223815917969,
                top: 63.682342529296875,
                right: null,
                bottom: null,
                width: 4.664524078369141,
                height: 2.0826950073242188,
                child: GeneratedVectorWidget273(),
              ),
              Positioned(
                left: 39.970115661621094,
                top: 65.24436950683594,
                right: null,
                bottom: null,
                width: 4.0613555908203125,
                height: 1.842376708984375,
                child: GeneratedVectorWidget274(),
              ),
              Positioned(
                left: 38.88444137573242,
                top: 66.72628021240234,
                right: null,
                bottom: null,
                width: 3.2571334838867188,
                height: 1.3217086791992188,
                child: GeneratedVectorWidget275(),
              ),
              Positioned(
                left: 47.90813446044922,
                top: 63.321876525878906,
                right: null,
                bottom: null,
                width: 3.642852783203125,
                height: 3.7648696899414062,
                child: GeneratedVectorWidget276(),
              ),
              Positioned(
                left: 49.597476959228516,
                top: 61.55960464477539,
                right: null,
                bottom: null,
                width: 9.231781005859375,
                height: 5.527149200439453,
                child: GeneratedVectorWidget277(),
              ),
              Positioned(
                left: 51.551048278808594,
                top: 63.201717376708984,
                right: null,
                bottom: null,
                width: 1.045501708984375,
                height: 3.885021209716797,
                child: GeneratedVectorWidget278(),
              ),
              Positioned(
                left: 53.64198684692383,
                top: 63.201717376708984,
                right: null,
                bottom: null,
                width: 1.0052871704101562,
                height: 3.885021209716797,
                child: GeneratedVectorWidget279(),
              ),
              Positioned(
                left: 55.893829345703125,
                top: 63.201717376708984,
                right: null,
                bottom: null,
                width: 1.0052909851074219,
                height: 3.885021209716797,
                child: GeneratedVectorWidget280(),
              ),
              Positioned(
                left: 57.9848518371582,
                top: 59.877437591552734,
                right: null,
                bottom: null,
                width: 3.257129669189453,
                height: 0.0,
                child: GeneratedVectorWidget281(),
              ),
              Positioned(
                left: 3.0963022708892822,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.302620887756348,
                height: 54.99110412597656,
                child: GeneratedVectorWidget282(),
              ),
              Positioned(
                left: 166.83712768554688,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.3026275634765625,
                height: 54.99110412597656,
                child: GeneratedVectorWidget283(),
              ),
              Positioned(
                left: 29.836889266967773,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.30262565612793,
                height: 54.99110412597656,
                child: GeneratedVectorWidget284(),
              ),
              Positioned(
                left: 15.481378555297852,
                top: 27.195159912109375,
                right: null,
                bottom: null,
                width: 4.101566314697266,
                height: 7.609844207763672,
                child: GeneratedVectorWidget285(),
              ),
              Positioned(
                left: 26.33847427368164,
                top: 27.195159912109375,
                right: null,
                bottom: null,
                width: 4.101554870605469,
                height: 7.609844207763672,
                child: GeneratedVectorWidget286(),
              ),
              Positioned(
                left: 13.591418266296387,
                top: 32.12153244018555,
                right: null,
                bottom: null,
                width: 0.8846511840820312,
                height: 0.8811492919921875,
                child: GeneratedVectorWidget287(),
              ),
              Positioned(
                left: 30.801944732666016,
                top: 32.12153244018555,
                right: null,
                bottom: null,
                width: 0.8846549987792969,
                height: 0.8811492919921875,
                child: GeneratedVectorWidget288(),
              ),
              Positioned(
                left: 18.61785316467285,
                top: 29.037546157836914,
                right: null,
                bottom: null,
                width: 3.2169055938720703,
                height: 1.9625396728515625,
                child: GeneratedVectorWidget289(),
              ),
              Positioned(
                left: 24.126842498779297,
                top: 29.037546157836914,
                right: null,
                bottom: null,
                width: 3.1767024993896484,
                height: 1.9625396728515625,
                child: GeneratedVectorWidget290(),
              ),
              Positioned(
                left: 7.479307651519775,
                top: 55.91230773925781,
                right: null,
                bottom: null,
                width: 13.993610382080078,
                height: 12.215789794921875,
                child: GeneratedVectorWidget291(),
              ),
              Positioned(
                left: 5.669803142547607,
                top: 55.91230773925781,
                right: null,
                bottom: null,
                width: 13.99360466003418,
                height: 12.215789794921875,
                child: GeneratedVectorWidget292(),
              ),
              Positioned(
                left: 7.720616340637207,
                top: 61.39939880371094,
                right: null,
                bottom: null,
                width: 5.790438652038574,
                height: 6.72869873046875,
                child: GeneratedVectorWidget293(),
              ),
              Positioned(
                left: 83.63970947265625,
                top: 17.14216423034668,
                right: null,
                bottom: null,
                width: 12.023223876953125,
                height: 14.538797378540039,
                child: GeneratedVectorWidget294(),
              ),
              Positioned(
                left: 85.08731842041016,
                top: 18.584030151367188,
                right: null,
                bottom: null,
                width: 9.127975463867188,
                height: 11.615015029907227,
                child: GeneratedVectorWidget295(),
              ),
              Positioned(
                left: 3.0963022708892822,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.302620887756348,
                height: 3.8768081665039062,
                child: GeneratedVectorWidget296(),
              ),
              Positioned(
                left: 29.836889266967773,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.342836380004883,
                height: 3.8768081665039062,
                child: GeneratedVectorWidget297(),
              ),
              Positioned(
                left: 166.83712768554688,
                top: 75.05705261230469,
                right: null,
                bottom: null,
                width: 4.3026275634765625,
                height: 3.8768081665039062,
                child: GeneratedVectorWidget298(),
              ),
              Positioned(
                left: 30.84217643737793,
                top: 33.76365661621094,
                right: null,
                bottom: null,
                width: 25.65485954284668,
                height: 24.431594848632812,
                child: GeneratedGroupWidget18(),
              )
            ]),
      ),
    );
  }
}
