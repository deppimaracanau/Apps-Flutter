package com.example.download_files

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
